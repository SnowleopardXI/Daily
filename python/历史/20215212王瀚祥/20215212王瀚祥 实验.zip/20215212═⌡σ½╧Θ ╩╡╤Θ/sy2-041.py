str_n=input("请输入一个整数：")
if str_n==str_n[::-1]:
    print("是回文数！")
else:
    print("不是回文数！")
