print("What is 2**2**3?",2**2**3)
print("100-25*3%4的结果为:",100-25*3%4)
print("is it true that 3+2<5-7?")
print(3+2<5-7)
print("What is 1<2<3?",1<2<3)
print("Oh,that is why it is True.")
print("How about some more.")
print("5 is greater than -2?",5>-2)
print("5 is greater or equal -2?",5>=-2)
print("5 is less or equal -2?",5<=-2)
print("表达式的结果为：",30-3**2+8//3**2*10)
x=2
x*=3+5**2
print("x结果为:",x)
