# sy1-01a.py the area of a circle
r=eval(input("请输入圆的半径"))
area=3.1415*r*r
perimeter=2*3.1414*r
print("圆的面积为：",area)
print("圆的面积为：{:.2f}".format(area))
print("圆的周长为：{:.2f}".format(perimeter))
