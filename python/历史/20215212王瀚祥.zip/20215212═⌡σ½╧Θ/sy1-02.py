# sy1-02a.py 求圆柱体积
r=eval(input("请输入圆柱底面圆的半径"))
h=eval(input("请输入圆柱的高"))
v=3.14*r*r*h
print("圆柱的体积为：{:.2f}".format(v))
