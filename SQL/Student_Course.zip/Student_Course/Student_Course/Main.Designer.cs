﻿namespace Student_Course
{
	partial class Main
	{
		/// <summary>
		/// 必需的设计器变量。
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// 清理所有正在使用的资源。
		/// </summary>
		/// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows 窗体设计器生成的代码

		/// <summary>
		/// 设计器支持所需的方法 - 不要修改
		/// 使用代码编辑器修改此方法的内容。
		/// </summary>
		private void InitializeComponent()
		{
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.课程管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.课程浏览ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.课程管理ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.课程添加ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.课程删除ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.课程修改ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.学生管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.学生浏览ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.学生管理ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.学生添加ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.学生删除ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.学生修改ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.外键检查ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.启用 = new System.Windows.Forms.ToolStripMenuItem();
            this.禁用 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.课程管理ToolStripMenuItem,
            this.学生管理ToolStripMenuItem,
            this.外键检查ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(8, 3, 0, 3);
            this.menuStrip1.Size = new System.Drawing.Size(1398, 30);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 课程管理ToolStripMenuItem
            // 
            this.课程管理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.课程浏览ToolStripMenuItem,
            this.课程管理ToolStripMenuItem1});
            this.课程管理ToolStripMenuItem.Name = "课程管理ToolStripMenuItem";
            this.课程管理ToolStripMenuItem.Size = new System.Drawing.Size(87, 24);
            this.课程管理ToolStripMenuItem.Text = "课程管理";
            // 
            // 课程浏览ToolStripMenuItem
            // 
            this.课程浏览ToolStripMenuItem.Name = "课程浏览ToolStripMenuItem";
            this.课程浏览ToolStripMenuItem.Size = new System.Drawing.Size(165, 26);
            this.课程浏览ToolStripMenuItem.Text = "课程浏览...";
            this.课程浏览ToolStripMenuItem.Click += new System.EventHandler(this.课程浏览ToolStripMenuItem_Click);
            // 
            // 课程管理ToolStripMenuItem1
            // 
            this.课程管理ToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.课程添加ToolStripMenuItem,
            this.课程删除ToolStripMenuItem,
            this.课程修改ToolStripMenuItem});
            this.课程管理ToolStripMenuItem1.Name = "课程管理ToolStripMenuItem1";
            this.课程管理ToolStripMenuItem1.Size = new System.Drawing.Size(165, 26);
            this.课程管理ToolStripMenuItem1.Text = "课程管理";
            // 
            // 课程添加ToolStripMenuItem
            // 
            this.课程添加ToolStripMenuItem.Name = "课程添加ToolStripMenuItem";
            this.课程添加ToolStripMenuItem.Size = new System.Drawing.Size(124, 26);
            this.课程添加ToolStripMenuItem.Text = "添加";
            this.课程添加ToolStripMenuItem.Click += new System.EventHandler(this.课程添加ToolStripMenuItem_Click);
            // 
            // 课程删除ToolStripMenuItem
            // 
            this.课程删除ToolStripMenuItem.Name = "课程删除ToolStripMenuItem";
            this.课程删除ToolStripMenuItem.Size = new System.Drawing.Size(124, 26);
            this.课程删除ToolStripMenuItem.Text = "删除";
            this.课程删除ToolStripMenuItem.Click += new System.EventHandler(this.课程删除ToolStripMenuItem_Click);
            // 
            // 课程修改ToolStripMenuItem
            // 
            this.课程修改ToolStripMenuItem.Name = "课程修改ToolStripMenuItem";
            this.课程修改ToolStripMenuItem.Size = new System.Drawing.Size(124, 26);
            this.课程修改ToolStripMenuItem.Text = "修改";
            // 
            // 学生管理ToolStripMenuItem
            // 
            this.学生管理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.学生浏览ToolStripMenuItem,
            this.学生管理ToolStripMenuItem1});
            this.学生管理ToolStripMenuItem.Name = "学生管理ToolStripMenuItem";
            this.学生管理ToolStripMenuItem.Size = new System.Drawing.Size(87, 24);
            this.学生管理ToolStripMenuItem.Text = "学生管理";
            // 
            // 学生浏览ToolStripMenuItem
            // 
            this.学生浏览ToolStripMenuItem.Name = "学生浏览ToolStripMenuItem";
            this.学生浏览ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.学生浏览ToolStripMenuItem.Text = "学生浏览...";
            this.学生浏览ToolStripMenuItem.Click += new System.EventHandler(this.学生浏览ToolStripMenuItem_Click);
            // 
            // 学生管理ToolStripMenuItem1
            // 
            this.学生管理ToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.学生添加ToolStripMenuItem1,
            this.学生删除ToolStripMenuItem1,
            this.学生修改ToolStripMenuItem1});
            this.学生管理ToolStripMenuItem1.Name = "学生管理ToolStripMenuItem1";
            this.学生管理ToolStripMenuItem1.Size = new System.Drawing.Size(224, 26);
            this.学生管理ToolStripMenuItem1.Text = "学生管理";
            // 
            // 学生添加ToolStripMenuItem1
            // 
            this.学生添加ToolStripMenuItem1.Name = "学生添加ToolStripMenuItem1";
            this.学生添加ToolStripMenuItem1.Size = new System.Drawing.Size(224, 26);
            this.学生添加ToolStripMenuItem1.Text = "添加";
            this.学生添加ToolStripMenuItem1.Click += new System.EventHandler(this.学生添加ToolStripMenuItem1_Click);
            // 
            // 学生删除ToolStripMenuItem1
            // 
            this.学生删除ToolStripMenuItem1.Name = "学生删除ToolStripMenuItem1";
            this.学生删除ToolStripMenuItem1.Size = new System.Drawing.Size(224, 26);
            this.学生删除ToolStripMenuItem1.Text = "删除";
            this.学生删除ToolStripMenuItem1.Click += new System.EventHandler(this.学生删除ToolStripMenuItem1_Click);
            // 
            // 学生修改ToolStripMenuItem1
            // 
            this.学生修改ToolStripMenuItem1.Name = "学生修改ToolStripMenuItem1";
            this.学生修改ToolStripMenuItem1.Size = new System.Drawing.Size(224, 26);
            this.学生修改ToolStripMenuItem1.Text = "修改";
            // 
            // 外键检查ToolStripMenuItem
            // 
            this.外键检查ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.启用,
            this.禁用});
            this.外键检查ToolStripMenuItem.Name = "外键检查ToolStripMenuItem";
            this.外键检查ToolStripMenuItem.Size = new System.Drawing.Size(87, 24);
            this.外键检查ToolStripMenuItem.Text = "外键检查";
            // 
            // 启用
            // 
            this.启用.Name = "启用";
            this.启用.Size = new System.Drawing.Size(124, 26);
            this.启用.Text = "启用";
            this.启用.Click += new System.EventHandler(this.启用_Click);
            // 
            // 禁用
            // 
            this.禁用.Name = "禁用";
            this.禁用.Size = new System.Drawing.Size(124, 26);
            this.禁用.Text = "禁用";
            this.禁用.Click += new System.EventHandler(this.禁用_Click);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1398, 872);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Main";
            this.Text = "学生课程管理";
            this.Load += new System.EventHandler(this.Main_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.MenuStrip menuStrip1;
		private System.Windows.Forms.ToolStripMenuItem 学生管理ToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem 学生浏览ToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem 课程管理ToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem 课程浏览ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 课程管理ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 学生管理ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 外键检查ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 启用;
        private System.Windows.Forms.ToolStripMenuItem 禁用;
        private System.Windows.Forms.ToolStripMenuItem 课程添加ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 课程删除ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 课程修改ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 学生添加ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 学生删除ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 学生修改ToolStripMenuItem1;
    }
}

